#!/usr/bin/perl -w

use strict;
use lib '.';
use interfaces;

my $app = interfaces->new();
$app->run();